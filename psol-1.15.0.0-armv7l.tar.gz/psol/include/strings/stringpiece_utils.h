// This is a placeholder to allow include-path compatibility with code written
// inside Google.

#ifndef STRINGS_STRINGPIECE_UTILS_H_
#define STRINGS_STRINGPIECE_UTILS_H_
#endif  // STRINGS_STRINGPIECE_UTILS_H_
